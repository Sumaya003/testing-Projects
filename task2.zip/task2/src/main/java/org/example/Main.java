package org.example;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class
Main {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();

        //Login SauceLabs
        driver.findElement(By.xpath("//input[@placeholder=\"Username\"]")).sendKeys("standard_user");
        driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("secret_sauce");
        driver.findElement(By.xpath("//input[@id=\"login-button\"]")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        try {
//            // Wait until alert is present
//            wait.until(ExpectedConditions.alertIsPresent());
//
//            // Switch to alert
//            Alert alert = driver.switchTo().alert();
//            alert.accept();
//        } catch (Exception e) {
//            System.out.println("No alert appeared");
//        }

        Thread.sleep(5000);

        //Add Items To Cart
        driver.findElement(By.xpath("//button[@id=\"add-to-cart-sauce-labs-bolt-t-shirt\"]")).click();
        driver.findElement(By.xpath("//button[@id=\"add-to-cart-test.allthethings()-t-shirt-(red)\"]")).click();
        Thread.sleep(1000);

        //Open Cart
        driver.findElement(By.xpath("//a[@class=\"shopping_cart_link\"]")).click();
        Thread.sleep(1000);

        //Checking if the items are added to cart and printing if any other items are there in cart which isnt added
        List<WebElement> cartItems = driver.findElements(By.className("inventory_item_name"));

        boolean boltTShirtFound = false;
        boolean redTShirtFound = false;

        for (WebElement item : cartItems) {
            String itemName = item.getText();
            System.out.println("Cart item: " + itemName);

            if (itemName.equalsIgnoreCase("Sauce Labs Bolt T-Shirt")) {
                boltTShirtFound = true;
            }
            if (itemName.equalsIgnoreCase("Test.allTheThings() T-Shirt (Red)")) {
                redTShirtFound = true;
            }

            else{
                System.out.println("Items That Are Not Added: " + itemName);
            }
        }

        if (boltTShirtFound && redTShirtFound) {
            System.out.println("Both items are successfully added to the cart!");
        } else {
            System.out.println("One or more items are missing from the cart.");
        }

        //Checkout
        driver.findElement(By.xpath("//button[@id=\"checkout\"]")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//button[@id=\"cancel\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[@id=\"continue-shopping\"]")).click();
        Thread.sleep(1000);

        //Add MMore Items
        driver.findElement(By.xpath("//button[@id=\"add-to-cart-sauce-labs-backpack\"]")).click();
        driver.findElement(By.xpath("//button[@id=\"add-to-cart-sauce-labs-fleece-jacket\"]")).click();
        Thread.sleep(1000);

        //Open Cart
        driver.findElement(By.xpath("//a[@class=\"shopping_cart_link\"]")).click();
        Thread.sleep(1000);

        //Check if Items added to the cart and previous items exist or not
        List<WebElement> newItemsCart = driver.findElements(By.className("inventory_item_name"));

        boltTShirtFound = false;
        redTShirtFound = false;
        boolean backpackFound = false;
        boolean fleeceFound = false;

        for(WebElement item : newItemsCart) {
            String itemName = item.getText();
            if (itemName.equalsIgnoreCase("Sauce Labs Bolt T-Shirt")) {
                boltTShirtFound = true;
            }
            if (itemName.equalsIgnoreCase("Test.allTheThings() T-Shirt (Red)")) {
                redTShirtFound = true;
            }

            if (itemName.equalsIgnoreCase("Sauce Labs Backpack")) {
                backpackFound = true;
            }
            if (itemName.equalsIgnoreCase("Sauce Labs Fleece Jacket")) {
                fleeceFound = true;
            }
        }

        //Checking Previous Items
        if(boltTShirtFound && redTShirtFound) {
            System.out.println("Previous items present in the cart!");
        }else{
            System.out.println("Previous items are missing from the cart.");
        }

        //Checking New Items
        if(backpackFound && fleeceFound) {
            System.out.println("New items are successfully added to the cart!");
        }else{
            System.out.println("New items are missing from the cart.");
        }

        //Checkout
        driver.findElement(By.xpath("//button[@id=\"checkout\"]")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys("Sumaya");
        driver.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys("Mohapatra");
        driver.findElement(By.xpath("//*[@id=\"postal-code\"]")).sendKeys("764059");
        Thread.sleep(1000);

        driver.findElement(By.xpath("//input[@id=\"continue\"]")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//button[@id=\"finish\"]")).click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//button[@id=\"back-to-products\"]")).click();
        Thread.sleep(1000);

        //Logout
        driver.findElement(By.xpath("//button[contains(text(),\"Open\")]")).click();
//        driver.findElement(By.xpath("//a[@id='logout_sidebar_link']")).click();

        WebElement logoutbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='logout_sidebar_link']")));
        logoutbtn.click();
        driver.quit();
    }
}

