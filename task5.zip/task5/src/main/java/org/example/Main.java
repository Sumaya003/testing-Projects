package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main() throws InterruptedException {

        WebDriver driver = new ChromeDriver();

        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        driver.manage().window().maximize();

        driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/p[2]/a")).click();

        List<WebElement> fields = driver.findElements(By.xpath("//div[@id='rightPanel']//input"));

        String base = "Sumaya";
        String uniqueUser = base + System.currentTimeMillis();


        String[] data = {
                "Sumaya", "Prakash", "Flat 301",
                "Hyderabad", "Telangana", "500104",
                "8117931188", "1310",
                uniqueUser, "24@Suma", "24@Suma"
        };

        for (int i = 0; i < fields.size() && i < data.length; i++) {
            fields.get(i).sendKeys(data[i]);
        }
        driver.findElement(By.xpath("//input[@value='Register']")).click();

        //Apply Loan
        driver.findElement(By.xpath("//a[contains(text(),'Request Loan')]")).click();
        driver.findElement(By.xpath("//*[@id=\"amount\"]")).sendKeys("1000");
        driver.findElement(By.xpath("//*[@id=\"downPayment\"]")).sendKeys("100");
        driver.findElement(By.xpath("//*[@type='button']")).click();

        driver.findElement(By.xpath("//a[contains(text(),'Accounts Overview')]")).click();
        Thread.sleep(2000);

        //Transferring Funds
        driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
        driver.findElement(By.xpath("//*[@id=\"amount\"]")).sendKeys("100");

        WebElement accountDropdown = driver.findElement(By.id("toAccountId"));
        accountDropdown.click();

        Thread.sleep(1000);
        Select select = new Select(accountDropdown);
        select.selectByIndex(1);

        driver.findElement(By.xpath("//*[@type='submit']")).click();
        driver.findElement(By.xpath("//a[contains(text(),'Accounts Overview')]")).click();
        Thread.sleep(2000);

        //LogOut
        driver.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
        }
    }
