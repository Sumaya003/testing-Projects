package org.example;

import org.json.simple.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        JSONObject data = JsonDataReader.readJSON("src/main/resources/package.json");

        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        driver.findElement(By.xpath("//*[@id='loginPanel']/p[2]/a")).click();

        List<WebElement> fields = driver.findElements(By.xpath("//div[@id='rightPanel']//input"));

        String uniqueUser = data.get("usernameBase").toString()+System.currentTimeMillis();

        String[] jData = {
                data.get("firstName").toString(),
                data.get("lastName").toString(),
                data.get("address").toString(),
                data.get("city").toString(),
                data.get("state").toString(),
                data.get("postalCode").toString(),
                data.get("phone").toString(),
                data.get("ssn").toString(),
                uniqueUser,
                data.get("password").toString(),
                data.get("password").toString()
        };

        for (int i = 0; i < fields.size() && i < jData.length; i++) {
            fields.get(i).sendKeys(jData[i]);
        }

        driver.findElement(By.xpath("//input[@value='Register']")).click();

        // Apply Loan
        driver.findElement(By.xpath("//a[contains(text(),'Request Loan')]")).click();
        driver.findElement(By.id("amount")).sendKeys("1000");
        driver.findElement(By.id("downPayment")).sendKeys("100");
        driver.findElement(By.xpath("//*[@type='button']")).click();

        driver.findElement(By.xpath("//a[contains(text(),'Accounts Overview')]")).click();
        Thread.sleep(2000);

        // Transfer Funds
        driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
        driver.findElement(By.id("amount")).sendKeys("100");

        WebElement accountDropdown = driver.findElement(By.id("toAccountId"));
        accountDropdown.click();

        Thread.sleep(1000);
        Select select = new Select(accountDropdown);
        select.selectByIndex(1);

        driver.findElement(By.xpath("//*[@type='submit']")).click();
        driver.findElement(By.xpath("//a[contains(text(),'Accounts Overview')]")).click();

        Thread.sleep(2000);
        driver.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();

        driver.quit();
    }
}
