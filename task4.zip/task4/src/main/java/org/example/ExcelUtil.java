package org.example;

import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;

public class ExcelUtil {
    public static String getCellData(String filePath, String sheetName, int row, int col) {
        String cellValue = "";
        try {
            FileInputStream fis = new FileInputStream(filePath);
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheet(sheetName);
            Row r = sheet.getRow(row);
            Cell c = r.getCell(col);
            workbook.close();

            if (c == null) return "";

            if (c.getCellType() == CellType.STRING) {
                cellValue = c.getStringCellValue();
            } else if (c.getCellType() == CellType.NUMERIC) {
                cellValue = String.valueOf((long) c.getNumericCellValue());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return cellValue;
    }
}
